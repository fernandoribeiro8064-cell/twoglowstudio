import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { GallerySection } from './components/GallerySection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { SERVICES } from './data/salonData';

export default function App() {
  const [preselectedService, setPreselectedService] = useState<string>(SERVICES[0].title);

  const handleSelectServiceForForm = (serviceTitle: string) => {
    setPreselectedService(serviceTitle);
    const contactEl = document.getElementById('contato');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-zinc-900">
      <Header />
      <main className="flex-1">
        <Hero />
        <ServicesSection onSelectServiceForForm={handleSelectServiceForForm} />
        <GallerySection />
        <TestimonialsSection />
        <FaqSection />
        <ContactSection preselectedService={preselectedService} />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
