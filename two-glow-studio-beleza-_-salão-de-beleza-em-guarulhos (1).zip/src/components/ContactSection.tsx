import React, { useEffect, useState } from 'react';
import {
  Check,
  Clock,
  Copy,
  ExternalLink,
  MapPin,
  MessageCircle,
  Phone,
} from 'lucide-react';
import { SALON_INFO, SERVICES, buildWhatsAppUrl } from '../data/salonData';

interface ContactSectionProps {
  preselectedService: string;
}

interface FormState {
  name: string;
  phone: string;
  service: string;
  period: string;
  notes: string;
}

interface FormErrors {
  name?: string;
  phone?: string;
  service?: string;
}

function formatBrazilianPhone(raw: string): string {
  const digits = raw.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 2) return digits;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  preselectedService,
}) => {
  const [form, setForm] = useState<FormState>({
    name: '',
    phone: '',
    service: preselectedService || SERVICES[0].title,
    period: 'Manhã (09h – 12h)',
    notes: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);
  const [copiedAddress, setCopiedAddress] = useState(false);

  useEffect(() => {
    if (preselectedService) {
      setForm((prev) => ({ ...prev, service: preselectedService }));
    }
  }, [preselectedService]);

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(SALON_INFO.address);
      setCopiedAddress(true);
      setTimeout(() => setCopiedAddress(false), 2500);
    } catch {
      setCopiedAddress(false);
    }
  };

  const validate = (): boolean => {
    const nextErrors: FormErrors = {};
    if (form.name.trim().length < 2) {
      nextErrors.name = 'Informe seu nome completo.';
    }
    const phoneDigits = form.phone.replace(/\D/g, '');
    if (phoneDigits.length < 10) {
      nextErrors.phone = 'Informe um WhatsApp válido com DDD.';
    }
    if (!form.service.trim()) {
      nextErrors.service = 'Selecione um serviço.';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const message = [
      `Olá, TWO GLOW STUDIO BELEZA! Gostaria de solicitar um agendamento:`,
      `• Nome: ${form.name.trim()}`,
      `• WhatsApp: ${form.phone.trim()}`,
      `• Serviço: ${form.service}`,
      `• Preferência de período: ${form.period}`,
      form.notes.trim() ? `• Observações: ${form.notes.trim()}` : null,
    ]
      .filter(Boolean)
      .join('\n');

    setSubmittedMessage(message);
  };

  return (
    <section id="contato" className="bg-zinc-50/70 py-16 md:py-24">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left: Institutional Address & Direct Channels */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <p className="text-xs font-semibold tracking-wide text-[#f43f5e] mb-2">
                Localização & Atendimento
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-zinc-900 [text-wrap:balance]">
                Agende sua visita no Gopouva.
              </h2>
              <p className="mt-3 text-sm md:text-base leading-relaxed text-zinc-600">
                Preencha o formulário de pré-agendamento ao lado ou entre em contato diretamente pelo
                nosso WhatsApp para confirmar o melhor horário.
              </p>
            </div>

            <div className="rounded-xl border border-zinc-200 bg-white p-6 space-y-5">
              <div className="flex items-start gap-3.5">
                <MapPin className="h-5 w-5 text-[#f43f5e] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-zinc-500">Endereço</div>
                  <p className="mt-1 text-sm font-medium text-zinc-900 leading-relaxed">
                    {SALON_INFO.address}
                  </p>
                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <a
                      href={SALON_INFO.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#e11d48] hover:underline"
                    >
                      <span>Abrir no Google Maps</span>
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
                    </a>
                    <span aria-hidden="true" className="text-zinc-300">
                      |
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyAddress}
                      className="inline-flex items-center gap-1.5 text-xs font-medium text-zinc-600 hover:text-zinc-900"
                    >
                      {copiedAddress ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-600" aria-hidden="true" />
                          <span className="text-emerald-700">Endereço copiado</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Copiar endereço</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <div className="border-t border-zinc-100 pt-4 flex items-start gap-3.5">
                <Phone className="h-5 w-5 text-[#f43f5e] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-zinc-500">Telefone & WhatsApp</div>
                  <a
                    href={buildWhatsAppUrl(
                      'Olá! Gostaria de falar com o atendimento do TWO GLOW STUDIO BELEZA.'
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-1 inline-block text-sm font-semibold text-zinc-900 hover:text-[#e11d48] tabular-nums"
                  >
                    {SALON_INFO.phoneFormatted}
                  </a>
                </div>
              </div>

              <div className="border-t border-zinc-100 pt-4 flex items-start gap-3.5">
                <Clock className="h-5 w-5 text-[#f43f5e] shrink-0 mt-0.5" aria-hidden="true" />
                <div>
                  <div className="text-xs font-semibold text-zinc-500">Horário de Funcionamento</div>
                  <p className="mt-1 text-sm font-medium text-zinc-900 tabular-nums">
                    {SALON_INFO.hours}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Validated Contact & WhatsApp Conversion Form */}
          <div className="lg:col-span-7">
            <div className="rounded-xl border border-zinc-200 bg-white p-6 md:p-8">
              {submittedMessage ? (
                <div className="py-4 space-y-5">
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <Check className="h-5 w-5" aria-hidden="true" />
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-zinc-900">
                      Pré-agendamento preparado com sucesso
                    </h3>
                    <p className="mt-2 text-sm md:text-base text-zinc-600 leading-relaxed">
                      Para confirmar seu horário em tempo real com nossa recepção, clique no botão
                      abaixo para enviar seus dados diretamente no nosso WhatsApp.
                    </p>
                  </div>

                  <div className="rounded-lg border border-zinc-200 bg-zinc-50 p-4 text-xs md:text-sm text-zinc-700 whitespace-pre-line leading-relaxed">
                    {submittedMessage}
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
                    <a
                      href={buildWhatsAppUrl(submittedMessage)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg bg-[#f43f5e] px-6 py-3 text-sm font-semibold text-white hover:bg-[#e11d48]"
                    >
                      <MessageCircle className="h-4 w-4" aria-hidden="true" />
                      <span>Enviar agora no WhatsApp</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => setSubmittedMessage(null)}
                      className="inline-flex min-h-[48px] items-center justify-center rounded-lg border border-zinc-200 px-5 py-3 text-sm font-medium text-zinc-700 hover:bg-zinc-50"
                    >
                      Editar informações
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <div>
                    <h3 className="text-xl font-semibold text-zinc-900">
                      Solicitar horário ou avaliação
                    </h3>
                    <p className="mt-1 text-sm text-zinc-500">
                      Preencha seus dados para gerar a mensagem pronta de atendimento no WhatsApp.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="block text-xs font-semibold text-zinc-700 mb-1.5"
                      >
                        Nome completo
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => {
                          setForm((prev) => ({ ...prev, name: e.target.value }));
                          if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                        }}
                        placeholder="Ex: Ana Paula Silva"
                        aria-invalid={Boolean(errors.name)}
                        className={`w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#f43f5e]/20 ${
                          errors.name
                            ? 'border-red-500 focus:border-red-500'
                            : 'border-zinc-200 focus:border-[#f43f5e]'
                        }`}
                      />
                      {errors.name && (
                        <p className="mt-1.5 text-xs font-medium text-red-600">{errors.name}</p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="contact-phone"
                        className="block text-xs font-semibold text-zinc-700 mb-1.5"
                      >
                        Seu WhatsApp
                      </label>
                      <input
                        id="contact-phone"
                        type="tel"
                        required
                        value={form.phone}
                        onChange={(e) => {
                          const formatted = formatBrazilianPhone(e.target.value);
                          setForm((prev) => ({ ...prev, phone: formatted }));
                          if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                        }}
                        placeholder="(11) 99999-9999"
                        aria-invalid={Boolean(errors.phone)}
                        className={`w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 tabular-nums focus:outline-none focus:ring-2 focus:ring-[#f43f5e]/20 ${
                          errors.phone
                            ? 'border-red-500 focus:border-red-500'
                            : 'border-zinc-200 focus:border-[#f43f5e]'
                        }`}
                      />
                      {errors.phone && (
                        <p className="mt-1.5 text-xs font-medium text-red-600">{errors.phone}</p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label
                        htmlFor="contact-service"
                        className="block text-xs font-semibold text-zinc-700 mb-1.5"
                      >
                        Serviço desejado
                      </label>
                      <select
                        id="contact-service"
                        value={form.service}
                        onChange={(e) =>
                          setForm((prev) => ({ ...prev, service: e.target.value }))
                        }
                        className="w-full min-h-[44px] rounded-lg border border-zinc-200 bg-white px-3.5 py-2.5 text-sm text-zinc-900 focus:border-[#f43f5e] focus:outline-none focus:ring-2 focus:ring-[#f43f5e]/20"
                      >
                        {SERVICES.map((srv) => (
                          <option key={srv.id} value={srv.title}>
                            {srv.title}
                          </option>
                        ))}
                        <option value="Avaliação Geral / Outro Procedimento">
                          Avaliação Geral / Outro Procedimento
                        </option>
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-period"
                        className="block text-xs font-semibold text-zinc-700 mb-1.5"
                      >
                        Preferência de horário
                      </label>
                      <select
                        id="contact-period"
                        value={form.period}
                        onChange={(e) =>
                          setForm((prev) => ({ ...prev, period: e.target.value }))
                        }
                        className="w-full min-h-[44px] rounded-lg border border-zinc-200 bg-white px-3.5 py-2.5 text-sm text-zinc-900 focus:border-[#f43f5e] focus:outline-none focus:ring-2 focus:ring-[#f43f5e]/20"
                      >
                        <option value="Manhã (09h – 12h)">Manhã (09h – 12h)</option>
                        <option value="Tarde (12h – 17h)">Tarde (12h – 17h)</option>
                        <option value="Final da tarde / Noite (17h – 20h)">
                          Final da tarde / Noite (17h – 20h)
                        </option>
                        <option value="Sábado (qualquer horário)">Sábado (qualquer horário)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-notes"
                      className="block text-xs font-semibold text-zinc-700 mb-1.5"
                    >
                      Observações ou histórico capilar (opcional)
                    </label>
                    <textarea
                      id="contact-notes"
                      rows={3}
                      value={form.notes}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, notes: e.target.value }))
                      }
                      placeholder="Conte se possui química recente, preferência de dia ou dúvidas específicas."
                      className="w-full rounded-lg border border-zinc-200 bg-white px-3.5 py-2.5 text-sm text-zinc-900 placeholder:text-zinc-400 focus:border-[#f43f5e] focus:outline-none focus:ring-2 focus:ring-[#f43f5e]/20"
                    />
                  </div>

                  <button
                    type="submit"
                    className="inline-flex w-full min-h-[48px] items-center justify-center gap-2 rounded-lg bg-[#f43f5e] px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#e11d48] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e]"
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden="true" />
                    <span>Continuar para o WhatsApp</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
