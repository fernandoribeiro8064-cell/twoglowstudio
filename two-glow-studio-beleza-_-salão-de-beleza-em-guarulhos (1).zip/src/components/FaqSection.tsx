import React, { useState } from 'react';
import { ChevronDown, MessageCircle } from 'lucide-react';
import { FAQS, buildWhatsAppUrl } from '../data/salonData';

export const FaqSection: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>(FAQS[0]?.id ?? null);

  const toggleItem = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faq" className="bg-white py-16 md:py-24 border-b border-zinc-200/80">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12">
          {/* Left Sticky Summary */}
          <div className="lg:col-span-5">
            <p className="text-xs font-semibold tracking-wide text-[#f43f5e] mb-2">
              Perguntas Frequentes
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-zinc-900 [text-wrap:balance]">
              Informações claras antes da sua visita.
            </h2>
            <p className="mt-4 text-sm md:text-base leading-relaxed text-zinc-600">
              Reunimos as principais dúvidas sobre agendamentos, avaliação capilar, biossegurança e
              localização no Gopouva. Caso precise de orientação personalizada, fale direto com
              nossa equipe.
            </p>

            <div className="mt-7">
              <a
                href={buildWhatsAppUrl(
                  'Olá! Tenho uma dúvida sobre os serviços do TWO GLOW STUDIO BELEZA.'
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-zinc-200 bg-white px-5 py-2.5 text-sm font-semibold text-zinc-900 transition-colors duration-150 hover:border-[#f43f5e] hover:text-[#e11d48] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e]"
              >
                <MessageCircle className="h-4 w-4 text-[#f43f5e]" aria-hidden="true" />
                <span>Tirar dúvida no WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Right Accordion */}
          <div className="lg:col-span-7 divide-y divide-zinc-200 border-t border-b border-zinc-200">
            {FAQS.map((item) => {
              const isOpen = openId === item.id;
              return (
                <div key={item.id}>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => toggleItem(item.id)}
                    className="flex w-full items-center justify-between gap-4 py-5 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e]"
                  >
                    <span className="text-base font-semibold text-zinc-900 leading-snug">
                      {item.question}
                    </span>
                    <ChevronDown
                      className={`h-5 w-5 shrink-0 text-zinc-500 transition-transform duration-200 ${
                        isOpen ? 'rotate-180 text-[#f43f5e]' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>

                  {isOpen && (
                    <div className="pb-5 pr-8 text-sm md:text-base leading-relaxed text-zinc-600">
                      {item.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
