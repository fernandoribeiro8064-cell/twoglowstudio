import React from 'react';
import { MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl } from '../data/salonData';

export const FloatingWhatsApp: React.FC = () => {
  const href = buildWhatsAppUrl(
    'Olá! Estou no site do TWO GLOW STUDIO BELEZA e gostaria de agendar um horário.'
  );

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Agendar atendimento pelo WhatsApp"
      className="fixed bottom-5 right-5 z-40 inline-flex h-13 w-13 md:h-auto md:w-auto md:px-4 md:py-3 items-center justify-center gap-2 rounded-full md:rounded-xl bg-[#f43f5e] text-white shadow-lg shadow-rose-500/25 transition-transform duration-150 hover:scale-[1.03] hover:bg-[#e11d48] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e]"
    >
      <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
      <span className="hidden md:inline text-sm font-semibold whitespace-nowrap">
        Falar no WhatsApp
      </span>
    </a>
  );
};
