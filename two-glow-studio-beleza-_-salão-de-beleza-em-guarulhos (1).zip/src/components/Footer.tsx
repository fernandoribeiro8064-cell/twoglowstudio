import React from 'react';
import { SALON_INFO, buildWhatsAppUrl } from '../data/salonData';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-zinc-200 py-12">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-zinc-200/80">
          <div className="md:col-span-5">
            <div className="font-display text-lg font-bold tracking-tight text-zinc-900">
              {SALON_INFO.brandFull}
            </div>
            <p className="mt-2.5 text-sm text-zinc-600 max-w-sm leading-relaxed">
              {SALON_INFO.subtitle}. Atendimento personalizado em coloração, tratamentos capilares,
              nail design e estética facial no Gopouva.
            </p>
          </div>

          <div className="md:col-span-3">
            <div className="text-xs font-semibold text-zinc-900 mb-3">Navegação</div>
            <ul className="space-y-2 text-sm text-zinc-600">
              <li>
                <a href="#servicos" className="hover:text-zinc-900 transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-zinc-900 transition-colors">
                  Galeria de Fotos
                </a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-zinc-900 transition-colors">
                  Depoimentos
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-zinc-900 transition-colors">
                  Perguntas Frequentes
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-zinc-900 transition-colors">
                  Contato
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <div className="text-xs font-semibold text-zinc-900 mb-3">Unidade Gopouva</div>
            <address className="not-italic text-sm text-zinc-600 space-y-2 leading-relaxed">
              <p>{SALON_INFO.address}</p>
              <p className="tabular-nums">{SALON_INFO.hours}</p>
              <p>
                <a
                  href={buildWhatsAppUrl(
                    'Olá! Gostaria de agendar um horário no TWO GLOW STUDIO BELEZA.'
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-[#e11d48] hover:underline tabular-nums"
                >
                  WhatsApp: {SALON_INFO.phoneFormatted}
                </a>
              </p>
            </address>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-zinc-500">
          <p>© {new Date().getFullYear()} {SALON_INFO.brandFull}. Todos os direitos reservados.</p>
          <p>Gopouva, Guarulhos – SP</p>
        </div>
      </div>
    </footer>
  );
};
