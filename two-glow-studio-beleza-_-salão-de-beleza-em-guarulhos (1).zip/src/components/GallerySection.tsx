import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, MessageCircle, X } from 'lucide-react';
import {
  GALLERY_ITEMS,
  GalleryCategory,
  GalleryItem,
  buildWhatsAppUrl,
} from '../data/salonData';
import { ResilientImage } from './ResilientImage';

const GALLERY_CATEGORIES: GalleryCategory[] = ['Todos', 'Resultados', 'Nosso Espaço'];

export const GallerySection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<GalleryCategory>('Todos');
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const filteredItems =
    activeCategory === 'Todos'
      ? GALLERY_ITEMS
      : GALLERY_ITEMS.filter((item) => item.category === activeCategory);

  const selectedItem: GalleryItem | null =
    selectedIndex !== null ? filteredItems[selectedIndex] ?? null : null;

  useEffect(() => {
    if (selectedIndex === null) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedIndex(null);
      } else if (e.key === 'ArrowRight') {
        setSelectedIndex((prev) =>
          prev === null ? null : (prev + 1) % filteredItems.length
        );
      } else if (e.key === 'ArrowLeft') {
        setSelectedIndex((prev) =>
          prev === null
            ? null
            : (prev - 1 + filteredItems.length) % filteredItems.length
        );
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIndex, filteredItems.length]);

  const handleCategoryChange = (category: GalleryCategory) => {
    setActiveCategory(category);
    setSelectedIndex(null);
  };

  return (
    <section id="galeria" className="bg-white py-16 md:py-24 border-b border-zinc-200/80">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-[#f43f5e] mb-2">
              Galeria de Fotos
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-zinc-900 [text-wrap:balance]">
              Resultados reais e a infraestrutura do nosso estúdio no Gopouva.
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Filtrar galeria"
            className="flex items-center gap-1.5 p-1.5 bg-zinc-100 rounded-xl w-fit"
          >
            {GALLERY_CATEGORIES.map((category) => {
              const isSelected = activeCategory === category;
              return (
                <button
                  key={category}
                  role="tab"
                  type="button"
                  aria-selected={isSelected}
                  onClick={() => handleCategoryChange(category)}
                  className={`min-h-[40px] px-4 py-2 text-xs md:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e] ${
                    isSelected
                      ? 'bg-white text-zinc-900 shadow-xs'
                      : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Asymmetric Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 auto-rows-[320px] md:auto-rows-[280px]">
          {filteredItems.map((item, idx) => {
            const isHeroSpan =
              activeCategory === 'Todos' && idx === 0
                ? 'md:col-span-2 md:row-span-2'
                : 'md:col-span-1';

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedIndex(idx)}
                className={`group relative overflow-hidden rounded-xl border border-zinc-200 bg-zinc-100 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e] ${isHeroSpan}`}
              >
                <ResilientImage
                  src={item.image}
                  alt={item.alt}
                  fallbackTitle={item.title}
                  className={`h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03] ${
                    item.objectPositionClass ?? 'object-center'
                  }`}
                />

                {/* Measured Contrast Scrim */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent flex flex-col justify-between p-5">
                  <div className="flex justify-end">
                    <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-white/90 text-zinc-900 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                      <Maximize2 className="h-4 w-4" aria-hidden="true" />
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 text-xs text-zinc-200 mb-1">
                      <span>{item.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.serviceTag}</span>
                    </div>
                    <h3 className="text-base md:text-lg font-semibold text-white">
                      {item.title}
                    </h3>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedItem && selectedIndex !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedItem.title}
          className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/85 p-4 md:p-8 backdrop-blur-xs"
          onClick={() => setSelectedIndex(null)}
        >
          <div
            className="relative w-full max-w-4xl overflow-hidden rounded-2xl bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-zinc-200 px-5 py-3.5">
              <div className="flex items-center gap-2 text-xs text-zinc-500 min-w-0">
                <span className="font-semibold text-zinc-900 truncate">
                  {selectedItem.title}
                </span>
                <span aria-hidden="true">·</span>
                <span className="whitespace-nowrap">{selectedItem.serviceTag}</span>
              </div>

              <button
                type="button"
                onClick={() => setSelectedIndex(null)}
                aria-label="Fechar visualização"
                className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="relative bg-zinc-950 h-[56vh] md:h-[62vh] w-full flex items-center justify-center">
              <ResilientImage
                src={selectedItem.image}
                alt={selectedItem.alt}
                fallbackTitle={selectedItem.title}
                className="h-full w-full object-contain"
              />

              {filteredItems.length > 1 && (
                <>
                  <button
                    type="button"
                    aria-label="Foto anterior"
                    onClick={() =>
                      setSelectedIndex(
                        (selectedIndex - 1 + filteredItems.length) % filteredItems.length
                      )
                    }
                    className="absolute left-3 top-1/2 -translate-y-1/2 inline-flex h-11 w-11 items-center justify-center rounded-lg bg-white/90 text-zinc-900 shadow-sm hover:bg-white"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Próxima foto"
                    onClick={() =>
                      setSelectedIndex((selectedIndex + 1) % filteredItems.length)
                    }
                    className="absolute right-3 top-1/2 -translate-y-1/2 inline-flex h-11 w-11 items-center justify-center rounded-lg bg-white/90 text-zinc-900 shadow-sm hover:bg-white"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                </>
              )}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 md:p-6">
              <p className="text-sm text-zinc-600 max-w-xl leading-relaxed">
                {selectedItem.caption}
              </p>

              <a
                href={buildWhatsAppUrl(
                  `Olá! Vi a foto "${selectedItem.title}" na galeria do TWO GLOW STUDIO BELEZA e gostaria de agendar uma avaliação.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#f43f5e] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#e11d48] whitespace-nowrap shrink-0"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                <span>Agendar este visual</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
