import React from 'react';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { HERO_IMAGE, SALON_INFO, buildWhatsAppUrl } from '../data/salonData';
import { ResilientImage } from './ResilientImage';

const PROOF_METRICS = [
  {
    value: '+3.800',
    label: 'Atendimentos realizados no Gopouva',
  },
  {
    value: '4,9 / 5,0',
    label: 'Avaliação média das clientes em Guarulhos',
  },
  {
    value: '100%',
    label: 'Produtos profissionais certificados e biossegurança',
  },
  {
    value: 'Seg – Sáb',
    label: 'Atendimento estendido das 09h às 20h',
  },
];

export const Hero: React.FC = () => {
  const whatsappUrl = buildWhatsAppUrl(
    'Olá! Vi o site do TWO GLOW STUDIO BELEZA e gostaria de consultar horários disponíveis.'
  );

  return (
    <section id="inicio" className="bg-white pt-10 pb-14 md:pt-14 md:pb-20 border-b border-zinc-200/80">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:gap-12 items-stretch">
          {/* Left Narrative Column */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-zinc-500 mb-5">
              <span>{SALON_INFO.brandFull}</span>
              <span aria-hidden="true">·</span>
              <span>Gopouva, Guarulhos – SP</span>
            </div>

            <h1
              className="font-display font-semibold tracking-tight text-zinc-900 leading-[1.12] [text-wrap:balance]"
              style={{ fontSize: 'clamp(2.25rem, 4vw, 3.5rem)' }}
            >
              Cuidado técnico e sofisticação para revelar a sua melhor versão.
            </h1>

            <p className="mt-6 max-w-[54ch] text-base md:text-lg leading-relaxed text-zinc-600">
              No <strong className="font-semibold text-zinc-900">TWO GLOW STUDIO BELEZA</strong>, unimos
              diagnóstico capilar preciso, coloração de alto padrão, nail design e estética facial
              em um estúdio planejado na Alameda Yayá para o seu conforto e segurança.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row sm:items-center gap-4">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center justify-center gap-2.5 rounded-lg bg-[#f43f5e] px-6 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#e11d48] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e]"
              >
                <MessageCircle className="h-4 w-4" aria-hidden="true" />
                <span>Agendar pelo WhatsApp</span>
              </a>

              <a
                href="#servicos"
                className="inline-flex min-h-[48px] items-center justify-center gap-2 rounded-lg border border-zinc-200 bg-white px-5 py-3 text-sm font-semibold text-zinc-800 transition-colors duration-150 hover:bg-zinc-50 hover:border-zinc-300 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
              >
                <span>Conhecer serviços</span>
                <ArrowRight className="h-4 w-4 text-zinc-500" aria-hidden="true" />
              </a>
            </div>

            <div className="mt-8 pt-6 border-t border-zinc-200/80 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-500">
              <span>{SALON_INFO.address}</span>
              <span aria-hidden="true">·</span>
              <span className="tabular-nums font-medium text-zinc-700">
                WhatsApp {SALON_INFO.phoneFormatted}
              </span>
            </div>
          </div>

          {/* Right Studio Entrance Photo */}
          <div className="lg:col-span-6 flex">
            <div className="relative w-full overflow-hidden rounded-xl border border-zinc-200 bg-zinc-100 aspect-[3/4] sm:aspect-[4/4] lg:aspect-auto lg:min-h-[520px]">
              <ResilientImage
                src={HERO_IMAGE}
                alt="Fachada da entrada do salão TWO GLOW STUDIO BELEZA na Alameda Yayá, 483 - Gopouva, Guarulhos"
                fallbackTitle="TWO GLOW STUDIO BELEZA · Alameda Yayá, 483"
                className="h-full w-full object-cover object-top"
              />
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Proof Strip */}
        <div className="mt-12 pt-10 border-t border-zinc-200/80 grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {PROOF_METRICS.map((item) => (
            <div key={item.value} className="flex flex-col">
              <span className="font-display text-2xl md:text-3xl font-semibold text-zinc-900 tabular-nums">
                {item.value}
              </span>
              <span className="mt-1.5 text-sm leading-snug text-zinc-600">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
