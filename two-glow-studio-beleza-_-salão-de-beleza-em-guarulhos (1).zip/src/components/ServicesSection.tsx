import React, { useState } from 'react';
import { ArrowUpRight, Check } from 'lucide-react';
import {
  SERVICES,
  SERVICE_CATEGORIES,
  ServiceCategory,
  buildWhatsAppUrl,
} from '../data/salonData';

interface ServicesSectionProps {
  onSelectServiceForForm: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectServiceForForm,
}) => {
  const [activeCategory, setActiveCategory] = useState<ServiceCategory>('Todos');

  const filteredServices =
    activeCategory === 'Todos'
      ? SERVICES
      : SERVICES.filter((service) => service.category === activeCategory);

  return (
    <section id="servicos" className="bg-zinc-50/70 py-16 md:py-24 border-b border-zinc-200/80">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-[#f43f5e] mb-2">
              Especialidades do Estúdio
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-zinc-900 [text-wrap:balance]">
              Protocolos executados sob medida para cada tipo de fio, pele e estilo.
            </h2>
          </div>

          <p className="max-w-md text-sm md:text-base text-zinc-600 leading-relaxed">
            Selecione uma especialidade abaixo para consultar valores iniciais e iniciar seu
            agendamento direto pelo WhatsApp com nossa recepção.
          </p>
        </div>

        {/* Interactive Filter Tabs */}
        <div
          role="tablist"
          aria-label="Filtrar serviços por especialidade"
          className="flex flex-wrap items-center gap-1.5 p-1.5 bg-zinc-200/60 rounded-xl w-fit max-w-full mb-10"
        >
          {SERVICE_CATEGORIES.map((category) => {
            const isSelected = activeCategory === category;
            return (
              <button
                key={category}
                role="tab"
                type="button"
                aria-selected={isSelected}
                onClick={() => setActiveCategory(category)}
                className={`min-h-[40px] px-4 py-2 text-xs md:text-sm font-medium rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e] ${
                  isSelected
                    ? 'bg-white text-zinc-900 shadow-xs'
                    : 'text-zinc-600 hover:text-zinc-900'
                }`}
              >
                {category}
              </button>
            );
          })}
        </div>

        {/* Services Editorial Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredServices.map((service) => {
            const serviceWaUrl = buildWhatsAppUrl(
              `Olá! Gostaria de agendar o serviço "${service.title}" no TWO GLOW STUDIO BELEZA.`
            );

            return (
              <article
                key={service.id}
                className="flex flex-col justify-between rounded-xl border border-zinc-200 bg-white p-6 md:p-8 transition-colors duration-150 hover:border-zinc-300"
              >
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-500 mb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-[#f43f5e] tabular-nums">
                        {service.number}.
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{service.category}</span>
                    </div>
                    <div className="flex items-center gap-2 tabular-nums">
                      <span>{service.duration}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-semibold text-zinc-900">{service.priceFrom}</span>
                    </div>
                  </div>

                  <h3 className="text-xl font-semibold text-zinc-900 leading-snug">
                    {service.title}
                  </h3>

                  <p className="mt-3 text-sm md:text-base leading-relaxed text-zinc-600">
                    {service.description}
                  </p>

                  <ul className="mt-5 space-y-2 border-t border-zinc-100 pt-4">
                    {service.highlights.map((highlight) => (
                      <li key={highlight} className="flex items-center gap-2.5 text-sm text-zinc-700">
                        <Check className="h-4 w-4 text-[#f43f5e] shrink-0" aria-hidden="true" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 pt-5 border-t border-zinc-100 flex flex-wrap items-center justify-between gap-3">
                  <a
                    href={serviceWaUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[42px] items-center gap-1.5 rounded-lg bg-[#f43f5e] px-4 py-2 text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#e11d48] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f43f5e]"
                  >
                    <span>Agendar este serviço</span>
                    <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={() => onSelectServiceForForm(service.title)}
                    className="inline-flex min-h-[42px] items-center px-3 py-2 text-xs font-medium text-zinc-600 hover:text-zinc-900 underline-offset-4 hover:underline whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-zinc-900"
                  >
                    Solicitar orçamento por formulário
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};
