import React from 'react';
import { Star } from 'lucide-react';
import { TESTIMONIALS } from '../data/salonData';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="depoimentos" className="bg-zinc-50/70 py-16 md:py-24 border-b border-zinc-200/80">
      <div className="mx-auto max-w-[1200px] px-5 md:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-[#f43f5e] mb-2">
              Depoimentos de Clientes
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-zinc-900 [text-wrap:balance]">
              A confiança de quem frequenta nosso estúdio em Guarulhos.
            </h2>
          </div>

          <div className="flex items-center gap-2 text-sm text-zinc-600 tabular-nums">
            <Star className="h-4 w-4 fill-[#f43f5e] text-[#f43f5e]" aria-hidden="true" />
            <span className="font-semibold text-zinc-900">4,9 / 5,0</span>
            <span aria-hidden="true">·</span>
            <span>Avaliação verificada de clientes</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item) => (
            <article
              key={item.id}
              className="flex flex-col justify-between rounded-xl border border-zinc-200 bg-white p-6 md:p-7"
            >
              <div>
                <div className="flex items-center justify-between gap-2 text-xs text-zinc-500 mb-4">
                  <span>{item.service}</span>
                  <span className="inline-flex items-center gap-1 font-semibold text-zinc-900 tabular-nums shrink-0">
                    <Star className="h-3.5 w-3.5 fill-[#f43f5e] text-[#f43f5e]" aria-hidden="true" />
                    {item.rating}
                  </span>
                </div>

                <blockquote className="text-sm md:text-base leading-relaxed text-zinc-700">
                  “{item.quote}”
                </blockquote>
              </div>

              <footer className="mt-6 pt-5 border-t border-zinc-100">
                <p className="text-xs font-medium text-[#e11d48] mb-2">
                  Resultado: {item.outcome}
                </p>
                <div className="text-sm font-semibold text-zinc-900">{item.name}</div>
                <div className="text-xs text-zinc-500">{item.location}</div>
              </footer>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
