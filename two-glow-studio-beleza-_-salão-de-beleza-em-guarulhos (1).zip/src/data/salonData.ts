export const SALON_INFO = {
  brandShort: 'TWO GLOW',
  brandFull: 'TWO GLOW STUDIO BELEZA',
  subtitle: 'Salão de beleza em Guarulhos',
  address: 'Alameda Yayá, 483 - Gopouva, Guarulhos - SP, 07060-000',
  addressShort: 'Alameda Yayá, 483 · Gopouva, Guarulhos',
  phoneRaw: '5511940478051',
  phoneFormatted: '(11) 94047-8051',
  hours: 'Segunda a Sábado · 09h às 20h',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Alameda+Yaya+483+Gopouva+Guarulhos+SP+07060-000',
};

export function buildWhatsAppUrl(message: string): string {
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${SALON_INFO.phoneRaw}?text=${encoded}`;
}

export type ServiceCategory =
  | 'Todos'
  | 'Cabelos & Coloração'
  | 'Tratamentos Capilares'
  | 'Unhas & Nail Design'
  | 'Sobrancelhas & Cílios';

export interface ServiceItem {
  id: string;
  number: string;
  category: Exclude<ServiceCategory, 'Todos'>;
  title: string;
  duration: string;
  priceFrom: string;
  description: string;
  highlights: string[];
}

export const SERVICE_CATEGORIES: ServiceCategory[] = [
  'Todos',
  'Cabelos & Coloração',
  'Tratamentos Capilares',
  'Unhas & Nail Design',
  'Sobrancelhas & Cílios',
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'mechas-iluminacao',
    number: '01',
    category: 'Cabelos & Coloração',
    title: 'Mechas Personalizadas & Morena Iluminada',
    duration: '3h30 – 4h30',
    priceFrom: 'A partir de R$ 420',
    description:
      'Diagnóstico de fundo de clareamento e técnica livre de marcas para luminosidade natural, acompanhada de proteção de pontes dissulfeto e finalização modelada.',
    highlights: ['Teste de mecha incluso', 'Matização sob medida', 'Reconstrução pós-química'],
  },
  {
    id: 'corte-visagismo',
    number: '02',
    category: 'Cabelos & Coloração',
    title: 'Corte Feminino com Visagismo & Escova',
    duration: '1h15',
    priceFrom: 'A partir de R$ 140',
    description:
      'Análise de proporções faciais e textura natural do fio para criar movimento, caimento leve e praticidade na rotina diária fora do salão.',
    highlights: ['Lavagem relaxante', 'Consultoria de finalização', 'Escova modelada'],
  },
  {
    id: 'coloracao-raiz',
    number: '03',
    category: 'Cabelos & Coloração',
    title: 'Coloração Global & Cobertura de Brancos',
    duration: '1h45',
    priceFrom: 'A partir de R$ 210',
    description:
      'Pigmentação profissional de alta fixação e brilho espelhado que preserva a integridade da fibra capilar com cobertura uniforme da raiz às pontas.',
    highlights: ['Linha profissional importada', 'Proteção do couro cabeludo', 'Brilho duradouro'],
  },
  {
    id: 'terapia-capilar',
    number: '04',
    category: 'Tratamentos Capilares',
    title: 'Protocolo de Reconstrução & Nutrição Profunda',
    duration: '1h10',
    priceFrom: 'A partir de R$ 180',
    description:
      'Reposição lipídica e proteica intensiva para cabelos sensibilizados por química ou calor térmico, devolvendo elasticidade, maciez e alinhamento.',
    highlights: ['Avaliação da fibra capilar', 'Ativos concentrados', 'Selagem térmica suave'],
  },
  {
    id: 'alinhamento-organico',
    number: '05',
    category: 'Tratamentos Capilares',
    title: 'Alinhamento Térmico & Controle de Frizz',
    duration: '2h30 – 3h00',
    priceFrom: 'A partir de R$ 290',
    description:
      'Redução de volume e disciplina dos fios com fórmula livre de formol, garantindo efeito natural, toque sedoso e secagem rápida no dia a dia.',
    highlights: ['Zero formol', 'Compatível com outras técnicas', 'Aspecto natural'],
  },
  {
    id: 'blindagem-gel',
    number: '06',
    category: 'Unhas & Nail Design',
    title: 'Esmaltação em Gel & Blindagem Natural',
    duration: '1h30',
    priceFrom: 'A partir de R$ 110',
    description:
      'Cutilagem cuidadosa combinada com reforço em gel estrutural para unhas resistentes, acabamento vitrificado e duração de até 21 dias sem descascar.',
    highlights: ['Autoclave hospitalar', 'Acabamento fino natural', 'Alta durabilidade'],
  },
  {
    id: 'alongamento-fibra',
    number: '07',
    category: 'Unhas & Nail Design',
    title: 'Alongamento em Fibra de Vidro & Manutenção',
    duration: '2h15',
    priceFrom: 'A partir de R$ 195',
    description:
      'Estrutura leve e anatomicamente curvada que acompanha o formato natural das mãos, com opções em francesinha reversa, baby boomer ou esmaltação neutra.',
    highlights: ['Formato personalizado', 'Curvatura natural', 'Biossegurança rigorosa'],
  },
  {
    id: 'brow-lash',
    number: '08',
    category: 'Sobrancelhas & Cílios',
    title: 'Design Estratégico, Brow Lamination & Lash Lifting',
    duration: '1h15',
    priceFrom: 'A partir de R$ 135',
    description:
      'Mapeamento facial preciso para harmonizar o olhar, associado ao alinhamento dos fios das sobrancelhas ou curvatura natural dos cílios sem extensões.',
    highlights: ['Mapeamento com paquímetro', 'Nutrição com queratina', 'Efeito natural por 6 semanas'],
  },
];

export type GalleryCategory = 'Todos' | 'Resultados' | 'Nosso Espaço';

export interface GalleryItem {
  id: string;
  title: string;
  category: Exclude<GalleryCategory, 'Todos'>;
  serviceTag: string;
  image: string;
  alt: string;
  caption: string;
  aspectClass: string;
  objectPositionClass?: string;
}

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-interior',
    title: 'Nosso Espaço & Estações de Atendimento',
    category: 'Nosso Espaço',
    serviceTag: 'Alameda Yayá, 483',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-12_at_16.59.00__3__68bd9795.jpeg',
    alt: 'Interior do TWO GLOW STUDIO BELEZA com espelhos iluminados, poltronas brancas e recepção no Gopouva',
    caption: 'Ambiente acolhedor e climatizado no Gopouva, com espelhos iluminados e estações confortáveis para o seu atendimento.',
    aspectClass: 'md:col-span-2 md:row-span-2',
    objectPositionClass: 'object-center',
  },
  {
    id: 'gal-balayage',
    title: 'Penteado Delicado & Brilho Natural',
    category: 'Resultados',
    serviceTag: 'Cabelo & Finalização',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-12_at_16.59.00_512b14e3.jpeg',
    alt: 'Cabelo castanho longo tratado e finalizado com penteado preso delicado no TWO GLOW STUDIO BELEZA',
    caption: 'Fios saudáveis, alinhados e com brilho intenso, finalizados com penteado delicado para ocasiões especiais.',
    aspectClass: 'md:col-span-1',
    objectPositionClass: 'object-top',
  },
  {
    id: 'gal-nails',
    title: 'Produção Completa: Make, Ondas & Iluminação',
    category: 'Resultados',
    serviceTag: 'Visagismo & Make',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-12_at_16.59.19_f339f961.jpeg',
    alt: 'Cliente sorrindo no salão com cabelo iluminado em ondas suaves e maquiagem social sofisticada',
    caption: 'Harmonia entre iluminação dos fios, ondas leves e maquiagem social pensada para realçar sua beleza natural.',
    aspectClass: 'md:col-span-1',
    objectPositionClass: 'object-[center_18%]',
  },
  {
    id: 'gal-brows',
    title: 'Mechas Loiras & Ondas Iluminadas',
    category: 'Resultados',
    serviceTag: 'Coloração & Mechas',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-12_at_16.59.00__1__16c6799e.jpeg',
    alt: 'Cabelo loiro com mechas iluminadas e ondas naturais visto de costas na cadeira do salão',
    caption: 'Clareamento dimensional com transição suave na raiz, matização sob medida e finalização em ondas naturais.',
    aspectClass: 'md:col-span-1',
    objectPositionClass: 'object-top',
  },
  {
    id: 'gal-spa',
    title: 'Dia da Noiva & Experiência Exclusiva',
    category: 'Nosso Espaço',
    serviceTag: 'Noivas & Eventos',
    image: '/assets/aistudio/WhatsApp_Image_2026-11-12_at_17.05.53_f4a795ce.jpeg',
    alt: 'Cantinho preparado para Dia da Noiva no TWO GLOW STUDIO BELEZA com vestido branco e mesa de café da manhã',
    caption: 'Preparação completa e atendimento reservado para noivas e debutantes, com mesa de café especial e suporte dedicado.',
    aspectClass: 'md:col-span-1',
    objectPositionClass: 'object-center',
  },
];

export interface TestimonialItem {
  id: string;
  name: string;
  location: string;
  service: string;
  rating: string;
  quote: string;
  outcome: string;
}

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'dep-1',
    name: 'Camila Ferreira',
    location: 'Gopouva, Guarulhos',
    service: 'Mechas Personalizadas & Reconstrução',
    rating: '5,0',
    quote:
      'Eu tinha receio de fazer mechas pelo histórico de ressecamento do meu cabelo. No Two Glow fizeram o teste de mecha antes, explicaram cada etapa e o resultado ficou exatamente no tom mel que eu buscava.',
    outcome: 'Fios iluminados sem quebra e cor intacta após 3 meses',
  },
  {
    id: 'dep-2',
    name: 'Juliana Mendes',
    location: 'Vila Augusta, Guarulhos',
    service: 'Blindagem em Gel & Design de Sobrancelhas',
    rating: '5,0',
    quote:
      'Atendimento extremamente pontual e ambiente impecável. Faço minhas unhas e sobrancelhas no mesmo horário antes do trabalho, com materiais esterilizados e acabamento que dura três semanas tranquilamente.',
    outcome: '21 dias de durabilidade no gel sem descolamento',
  },
  {
    id: 'dep-3',
    name: 'Mariana Costa',
    location: 'Centro, Guarulhos',
    service: 'Corte com Visagismo & Terapia Capilar',
    rating: '5,0',
    quote:
      'Desde a recepção até a finalização, o cuidado técnico faz toda a diferença. O corte trouxe leveza para o meu rosto e aprendi a finalizar em casa em menos de dez minutos.',
    outcome: 'Corte prático e recuperação total da maciez dos fios',
  },
];

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export const FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    question: 'Como funciona o agendamento pelo WhatsApp?',
    answer:
      'Você escolhe o serviço desejado aqui no site ou envia uma mensagem direta para o nosso WhatsApp (11) 94047-8051. Nossa equipe confirma a disponibilidade de horário em minutos e realiza uma pré-avaliação rápida caso você vá realizar procedimentos químicos.',
  },
  {
    id: 'faq-2',
    question: 'É necessário fazer teste de mecha antes de procedimentos de coloração ou mechas?',
    answer:
      'Sim. Para garantir a saúde e integridade do seu cabelo, realizamos avaliação capilar e teste de mecha antes de qualquer procedimento de descoloração ou transformação. Assim asseguramos o tom ideal sem comprometer a estrutura dos fios.',
  },
  {
    id: 'faq-3',
    question: 'Quais formas de pagamento o salão aceita?',
    answer:
      'Aceitamos Pix, dinheiro, cartões de débito e cartões de crédito com parcelamento em até 4x sem juros para serviços e pacotes acima de R$ 250.',
  },
  {
    id: 'faq-4',
    question: 'O salão possui facilidade de acesso e estacionamento no Gopouva?',
    answer:
      'Estamos localizados na Alameda Yayá, 483, uma das vias mais tradicionais e acessíveis do Gopouva em Guarulhos, com vagas de fácil acesso na região e proximidade a pontos de transporte e comércio local.',
  },
  {
    id: 'faq-5',
    question: 'Qual é a política de remarcação ou cancelamento?',
    answer:
      'Caso precise alterar seu horário, pedimos apenas que nos avise pelo WhatsApp com no mínimo 12 horas de antecedência para que possamos realocar sua agenda sem custos.',
  },
  {
    id: 'faq-6',
    question: 'Vocês utilizam materiais esterilizados nos atendimentos de manicure e sobrancelhas?',
    answer:
      'Sim. Seguimos protocolo rigoroso de biossegurança: todos os alicates, espátulas e pinças metálicas passam por lavagem enzimática e esterilização em autoclave hospitalar com embalagem individual aberta na presença da cliente, além do uso de lixas e palitos descartáveis.',
  },
];

export const HERO_IMAGE = '/assets/aistudio/WhatsApp_Image_2026-11-12_at_16.59.00__2__d651a75f.jpeg';
